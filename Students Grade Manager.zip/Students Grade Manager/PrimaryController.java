
/**
 *446009584,Lamar
 *446002363,Roaa
 *446002564,sahar
 *446001209,reham
 */

package com.mycompany.finaladvanpro;
//from Scene Builder
import javafx.event.ActionEvent; // when ew press the button to log in
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class PrimaryController {
    //L for lable
    @FXML // IF WE DIDNT BUT IT IT WILL GIVE US NULL EXEPTION
    // OT IS LIKE A BRIDGE BETWEEN JAVA AND FXML
    private TextField nameL;
    @FXML private TextField IdL; 
    @FXML private PasswordField PsL;
    @FXML private Label Password;
    @FXML private Label id;
    @FXML private Label name;
    @FXML private Button primaryButton;
    @FXML private Label welcome;
    
// the Condetion for Entring The System

    @FXML // WE LINKE AN ACTION NOT A VARIABLE
            
    void switchToSecondary(ActionEvent event) { // I CAN DELET THIS PARAMETER AND COSE NO ERROR
        String enteredName = nameL.getText().trim();
        String enteredID = IdL.getText().trim();// BILT IN AND PRE-DEFINDE METHODE
        String enteredPassword = PsL.getText();

        if (enteredName.isEmpty() || enteredID.isEmpty() || enteredPassword.isEmpty()) {
            welcome.setText("Please fill in all fields!");
            return;
        }

        if ((enteredName.equals("Roaa") && enteredID.equals("446002363") && enteredPassword.equals("Roaa123")) ||
            (enteredName.equals("Sahar") && enteredID.equals("446002564") && enteredPassword.equals("Sahar123")) ||
            (enteredName.equals("Reham") && enteredID.equals("446001209") && enteredPassword.equals("Reham123")) ||
            (enteredName.equals("Lamar") && enteredID.equals("446009584") && enteredPassword.equals("Lamar123"))) {
            changeScene();
        } else {
            welcome.setText("Wrong ID or Password or User name!");
        }
    }
// Chnge the Scene from the Log in page to the Home page

    private void changeScene() {
        javafx.application.Platform.runLater(() -> {
            try {
                App.setRoot("secondary");
            } catch (Exception e) {
                welcome.setText("Error entering dashboard.");
                e.printStackTrace();
            }
        });
    }
}