/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *446009584,Lamar
 *446002363,Roaa
 *446002564,sahar
 *446001209,reham
 */

package com.mycompany.finaladvanpro;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class ViewStudentsController implements Initializable {

    // Components connected to Scene Builder components
    @FXML private TableView<Student> studentTable;
    @FXML private TableColumn<Student, String> colID;
    @FXML private TableColumn<Student, String> colName;
    @FXML private TableColumn<Student, String> colGrade;
    @FXML private Button btnViewReport;
    @FXML private Button btnBack;

    // List to store the student data dynamically for the table view
    private ObservableList<Student> studentList = FXCollections.observableArrayList();

    // Runs automatically when this screen is opened
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Link the columns to the properties inside the Student class
        colID.setCellValueFactory(cellData -> cellData.getValue().idProperty());
        colName.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        colGrade.setCellValueFactory(cellData -> cellData.getValue().gradeProperty());
        
        // Load the text file data directly into the table
        loadStudentData();
    }

    // Method to read student info from the text file and add it to the table
    private void loadStudentData() {
        studentList.clear(); // Clear the list first to avoid duplicates
        File file = new File("students.txt");

        // Print error message if the file cannot be found
        if (!file.exists()) {
            System.out.println("students.txt source registry missing.");
            return;
        }

        // Open file and read lines one by one
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue; // Skip any accidental empty lines

                String[] data = line.split(",");
                // If the row contains at least ID and Name, extract the data
                if (data.length >= 2) {
                    String id = data[0].trim();
                    String name = data[1].trim();
                    
                    // If no grade exists yet in the text file line, set it to N/A
                    String grade = (data.length >= 3) ? data[2].trim() : "N/A";
                    
                    // Create a new student object and add it to the list
                    studentList.add(new Student(id, name, grade));
                }
            }
            // Set the items to display them on the user screen
            studentTable.setItems(studentList);
        } catch (IOException e) {
            System.out.println("Error building table array lists.");
            e.printStackTrace();
        }
    }

    // Go to the View Report view scene
    @FXML
    void switchToViewReport(ActionEvent event) {
        try {
            App.setRoot("ViewReport"); 
        } catch (IOException e) {
            System.out.println("Error loading report view pane.");
            e.printStackTrace();
        }
    }

    // Go back to the main dashboard menu (secondary scene)
    @FXML
    void switchToSecondary(ActionEvent event) {
        try {
            App.setRoot("secondary"); 
        } catch (IOException e) {
            System.out.println("Error loading secondary screen view dashboard framework.");
            e.printStackTrace();
        }
    }
}