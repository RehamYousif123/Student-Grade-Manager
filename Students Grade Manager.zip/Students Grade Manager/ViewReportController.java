/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *446009584,Lamar
 *446002363,Roaa
 *446002564,sahar
 *446001209,reham
 */

package com.mycompany.finaladvanpro;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ViewReportController implements Initializable {

    // UI elements linked to the FXML layout report fields
    @FXML private Label lblTotalStudents;
    @FXML private Label lblAverageGrade;
    @FXML private Label lblHighestGrade;
    @FXML private Label lblLowestGrade;
    @FXML private Button btnBack;

    // Automatically calculates statistics as soon as this screen opens
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        generateReportMetrics();
    }

    // Reads the data file and calculates the student performance details
    private void generateReportMetrics() {
        File file = new File("students.txt");
        
        // Safety check: if file is missing, set default values and exit
        if (!file.exists()) {
            lblTotalStudents.setText("Total Registered Students: 0");
            lblAverageGrade.setText("Average Grade: N/A");
            return;
        }

        // Initialize counters and variables for tracking metrics
        int totalStudents = 0;
        double sum = 0;
        int gradedCount = 0;
        double highest = Double.MIN_VALUE; // Starts at lowest possible value to catch any real grade
        double lowest = Double.MAX_VALUE;   // Starts at highest possible value to catch any real grade

        // Open and read the text file line by line
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue; // Skip accidental blank lines
                
                String[] data = line.split(",");
                // If the line has at least an ID and a Name, count it as a registered student
                if (data.length >= 2) { 
                    totalStudents++;
                    
                    // If the line also contains a grade element at the end
                    if (data.length >= 3) {
                        try {
                            double grade = Double.parseDouble(data[2].trim());
                            sum += grade;
                            gradedCount++;
                            
                            // Track highest and lowest grades found so far
                            if (grade > highest) highest = grade;
                            if (grade < lowest) lowest = grade;
                        } catch (NumberFormatException e) {
                            // Safely handles entries with missing or corrupted grades
                        }
                    }
                }
            }

            // Display total registered student count
            lblTotalStudents.setText("Total Registered Students: " + totalStudents);
            
            // If grades were found, display the final statistics
            if (gradedCount > 0) {
                double average = sum / gradedCount;
                lblAverageGrade.setText("Average Grade: " + String.format("%.2f", average));
                lblHighestGrade.setText("Highest Grade: " + highest);
                lblLowestGrade.setText("Lowest Grade: " + lowest);
            } else {
                // Display placeholder values if no grades have been inputted yet
                lblAverageGrade.setText("Average Grade: No grades added yet");
                lblHighestGrade.setText("Highest Grade: N/A");
                lblLowestGrade.setText("Lowest Grade: N/A");
            }

        } catch (IOException e) {
            System.out.println("Error processing metrics engines.");
            e.printStackTrace();
        }
    }

    // Navigates back to the View Students list view screen
    @FXML
    void switchToViewStudents(ActionEvent event) {
        try {
            App.setRoot("ViewStudents"); 
        } catch (IOException e) {
            System.out.println("Error processing redirect target.");
            e.printStackTrace();
        }
    }
}