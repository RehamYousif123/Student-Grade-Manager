/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */




/**
 *446009584,Lamar
 *446002363,Roaa
 *446002564,sahar
 *446001209,reham
 */


 
package com.mycompany.finaladvanpro; 

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.Label; 
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddGradesController implements Initializable {
    // Text field for entering student ID
    @FXML private TextField studentIDField;
    
    // Text field for entering grade

    @FXML private TextField gradeField;
        // Label used to display the average grade
    
    @FXML private Label averageLabel;
    
    @FXML private Label AddGrades;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
         // No initialization required
    }

    /**
     * Saves a grade after verifying that the student exists.
     */
    @FXML
    void handleSaveGrade(ActionEvent event) {
        String studentID = studentIDField.getText().trim();
        String grade = gradeField.getText().trim();
    // Check that all fields are filled
        if (studentID.isEmpty() || grade.isEmpty()) {
            AddGrades.setText("Please fill all fields!");
            return;
        }

        File file = new File("students.txt");
                // Check that all fields are filled
        if (!file.exists()) {
            AddGrades.setText("Error: students.txt data missing.");
            return;
        }
        // Check if the student ID exists in students.txt

        boolean studentFound = false;
        List<String> updatedLines = new ArrayList<>();

        // Reads line by line, isolating parameters safely to inject the grade score
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] data = line.split(",");
                if (data.length >= 2 && data[0].trim().equals(studentID)) {
                    // Update structure: ID, Name, Grade score evaluation
                    line = data[0].trim() + "," + data[1].trim() + "," + grade;
                    studentFound = true;
                }
                updatedLines.add(line);
            }
        } catch (IOException e) {
            AddGrades.setText("Error tracking file parsing records.");
            e.printStackTrace();
            return;
        }

        if (studentFound) {
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
                for (String line : updatedLines) {
                    bw.write(line);
                    bw.newLine();
                }
                AddGrades.setText("Grade saved successfully!");
                  // Clear input fields after saving
                studentIDField.clear();
                gradeField.clear();
            } catch (IOException e) {
                AddGrades.setText("Error updating system database.");
                e.printStackTrace();
            }
        } else {
                    // Stop if student ID does not exist

            AddGrades.setText("Student ID not found in records!");
        }
    }

    /**
     * Returns user to Home screen.
     */
    @FXML
    void switchToDashboard(ActionEvent event) {
        javafx.application.Platform.runLater(() -> {
            try {
                App.setRoot("secondary");
            } catch (Exception e) {
                AddGrades.setText("Error returning to dashboard.");
                e.printStackTrace();
            }
        });
    }

    /**
     * Calculates average of all grades stored in grades.txt.
     */
    @FXML
    void calculateAverage(ActionEvent event) {
        double sum = 0;
        int count = 0;
        File file = new File("students.txt");

        if (!file.exists()) {
            averageLabel.setText("No students database exists.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] data = line.split(",");
                if (data.length == 3) {
                    try {
                        sum += Double.parseDouble(data[2].trim());
                        count++;
                    } catch (NumberFormatException e) {
                        // Ignore non-numeric formats smoothly
                    }
                }
            }
                        // Display average if grades exist
            if (count > 0) {
                averageLabel.setText("Average: " + String.format("%.2f", (sum / count)));
            } else {
                averageLabel.setText("No graded student fields found");
            }
        } catch (Exception e) {
            averageLabel.setText("Error reading statistics computation.");
            e.printStackTrace();
        }
    }
}