
 
package com.mycompany.finaladvanpro;
//from Scene Builder

import java.io.BufferedWriter;
import java.io.FileWriter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class NewStudent {
    
    //L for lable

    @FXML private Button AddNS;
    @FXML private Label AddStudent;
    @FXML private Button GoHome;
    @FXML private Label NewStID;
    @FXML private Label NewStName;
    @FXML private TextField StNewID;
    @FXML private TextField StNewName;
// the Condetion for Adding a New Student

    @FXML
    void handleAddStudent(ActionEvent event) {
        String studentID = StNewID.getText().trim();
        String studentName = StNewName.getText().trim();

        if (studentID.isEmpty() || studentName.isEmpty()) {
            AddStudent.setText("Please fill in all fields!");
            return;
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("students.txt", true))) {
            // New students are written into base dataset layout structure
            bw.write(studentID + "," + studentName);
            bw.newLine();

            AddStudent.setText("Saved to file successfully!");
            StNewID.clear();
            StNewName.clear();
        } catch (Exception e) {
            AddStudent.setText("Error saving student record.");
            e.printStackTrace();
        }
    }
// Change the scene from Add new Student Screen to the Home Screen

    @FXML
    void switchToSecondary(ActionEvent event) {
        javafx.application.Platform.runLater(() -> {
            try {
                App.setRoot("secondary"); 
            } catch (Exception e) {
                AddStudent.setText("Error loading main dashboard screen.");
                e.printStackTrace();
            }
        });
    }
}