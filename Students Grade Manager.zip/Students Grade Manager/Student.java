/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *446009584,Lamar
 *446002363,Roaa
 *446002564,sahar
 *446001209,reham
 */

package com.mycompany.finaladvanpro;

import javafx.beans.property.SimpleStringProperty;

public class Student {
    // Use SimpleStringProperty so the TableView can automatically track and update data
    private final SimpleStringProperty id;
    private final SimpleStringProperty name;
    private final SimpleStringProperty grade;

    // Constructor to create a new Student object with ID, Name, and Grade
    public Student(String id, String name, String grade) {
        this.id = new SimpleStringProperty(id);
        this.name = new SimpleStringProperty(name);
        this.grade = new SimpleStringProperty(grade);
    }

    // Getter methods to extract standard text strings from the properties
    public String getId() { 
        return id.get(); 
    }
    public String getName() { 
        return name.get(); 
    }
    public String getGrade() { 
        return grade.get();
    }

    // Property methods required by JavaFX columns to bind and sync variables to the table rows
    public SimpleStringProperty idProperty() { 
        return id;
    }
    public SimpleStringProperty nameProperty() { 
        return name; 
    }
    public SimpleStringProperty gradeProperty() {
        return grade;
    }
}