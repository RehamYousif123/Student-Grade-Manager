/**
 *446009584,Lamar
 *446002363,Roaa
 *446002564,sahar
 *446001209,reham
 */


 

package com.mycompany.finaladvanpro;

//from Scene Builder

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class SecondaryController {

    @FXML private Button AddGr;
    @FXML private Button AddSt;
    @FXML private Label Home;
    @FXML private Button ViewRe;
    @FXML private Button ViewSt;
// Change the Scene From the Home screen to the grade editor screen 
    @FXML
    void switchToAddGrades(ActionEvent event) {
        try {
            App.setRoot("AddGrades"); 
        } catch (java.io.IOException e) {
            System.out.println("Error loading Add Grades screen.");
            e.printStackTrace();
        }
    }
   // Change the Scene From the Home screen to the Add new Student screen 
    @FXML
    void switchToNewStudent(ActionEvent event) {
        try {
            App.setRoot("StudentNewAdd"); 
        } catch (java.io.IOException e) {
            System.out.println("Error loading New Student screen.");
            e.printStackTrace();
        }
    }

     // Change the Scene From the Home screen to the viwe Student screen 
    @FXML
    void switchToViewStudents(ActionEvent event) {
        try {
            App.setRoot("ViewStudents"); 
        } catch (java.io.IOException e) {
            System.out.println("Error loading View Students screen.");
            e.printStackTrace();
        }
    }

     // Change the Scene From the Home screen to the view Report screen 
    @FXML
    void switchToViewReport(ActionEvent event) {
        try {
            App.setRoot("ViewReport"); 
        } catch (java.io.IOException e) {
            System.out.println("Error loading View Report screen.");
            e.printStackTrace();
        }
    }
    
 // Change the Scene From the any scene to the Home screen 
    @FXML
    void switchToPrimary(ActionEvent event) {
        try {
            App.setRoot("primary"); 
        } catch (java.io.IOException e) {
            System.out.println("Error loading Login screen.");
            e.printStackTrace();
        }
    }
}